#include "stdint.h"
#include "stdbool.h"
#include "inc/tm4c123gh6pm.h"
#include "inc/hw_gpio.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"
#include "math.h"

void portf_1_pin_high();
void portf_1_pin_low();
void portf_1_pin_write(int value);
void portf_1_pin_write_v2(int value);
void portf_write(int pin , int value);


void main(void)
{

    SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|SYSCTL_OSC_MAIN);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 8);


}

void portf_1_pin_high()
{
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 2);
}
void portf_1_pin_low()
{
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
}
void portf_1_pin_write(int value)
{
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, value);
}
void portf_1_pin_write_v2(int value)
{
    GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, pow(2,value));
}
void portf_write(int pin , int value)
{

}
